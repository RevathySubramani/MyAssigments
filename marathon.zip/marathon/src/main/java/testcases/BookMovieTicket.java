package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecific;
import pages.JusTickets.JusTicketsHomePage;

public class BookMovieTicket extends ProjectSpecific{
	
	@Test (dataProvider="excelData")
	public void bookTicket(String city, String cardNo, String expiryDate, String cvv, String name, String email, String phone) throws InterruptedException {
		new JusTicketsHomePage(driver)
		.clickLocation()
		.enterLocation(city)
		.selectLocation()
		.selectMovie()
		.validateMovieDetails()
		.selectShowTime()
		.selectSeat()
		.clickConfirm()
		.reviewBookingDetails()
		.choosePayment()
		.enterPaymentDetails(cardNo, expiryDate, cvv, name, email, phone)
		.verifyButtonEnabled();
	}
	
	@BeforeTest
	public void setValues() {
		fileName="TicketBookingDetails";
	}
	

}
