package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecific;
import pages.RedHat.RedHatLoginPage;

public class RegisterRedHatUser extends ProjectSpecific {
		
		@Test (dataProvider="excelData")
		public void registerNewUser(String userID, String password, String confirmPassword, String firstName, String lastName,
				String email, String phone, String job, String address1, String address2, String postalCode, String city) 
						throws InterruptedException {
			new RedHatLoginPage(driver)
			.clickRegister()
			.validatePageTitle()
			.isRegisterFormDisplayed()
			.enterUserDetails(userID, password, confirmPassword, firstName, lastName, email, phone, job)
			.selectAccountType()
			.selectCountry()
			.enterContactInformation(address1, address2, postalCode, city)
			.selectState();
		}
		
		@BeforeTest
		public void setValues() {
			fileName="RedHatNewUserDetails";
		}

}
