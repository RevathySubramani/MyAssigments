package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.Alert;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import utils.ReadExcelData;

public class ProjectSpecific {
	
	public ChromeDriver driver;
	public Alert alert;
	public String fileName;
	public int sheetNumber;
	public static WebDriverWait wait;
	public ChromeOptions ch;
	
	
	@Parameters({"application"})
	@BeforeMethod
	public void preConditions(String application) throws IOException {
		
		FileInputStream file = new FileInputStream("./src/main/resources/"+application+".properties");
		Properties prop = new Properties();
		prop.load(file);
		ch=new ChromeOptions();
		ch.addArguments("--disable-notifications");
		driver = new ChromeDriver(ch);
		driver.manage().window().maximize();
		driver.get(prop.getProperty("url"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}
	
	@AfterMethod
	public void postConditions() {
		driver.close();
	}
	
	@DataProvider (name="excelData")
	public String[][] getData() throws IOException {
		String[][] data = ReadExcelData.readExcelData(fileName);
		return data;
	}

}
