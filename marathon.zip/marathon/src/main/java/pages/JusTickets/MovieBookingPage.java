package pages.JusTickets;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecific;

public class MovieBookingPage extends ProjectSpecific{
	
	public MovieBookingPage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public MovieBookingPage selectSeat() {
		driver.findElement(By.xpath("//div[contains(@class,'seat available')]//div[@class='label']")).click();
		driver.findElement(By.xpath("(//div[contains(@class,'seat available')]//div[@class='label'])[2]")).click();
		return new MovieBookingPage(driver);
	}
	
	public MovieOrderPage clickConfirm() {
		driver.findElement(By.xpath("//span[contains(text(),'Confirm')]")).click();
		return new MovieOrderPage(driver);
		
	}

}
