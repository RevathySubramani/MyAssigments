package pages.JusTickets;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ProjectSpecific;

public class MovieDetailsPage extends ProjectSpecific{
	
	public MovieDetailsPage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public MovieDetailsPage validateMovieDetails() {
		if(driver.findElement(By.xpath("//h2[@class='name']")).isDisplayed()) {
			System.out.println("Selected Movie Title - "+ driver.findElement(By.xpath("//h2[@class='name']")).getText());
		}
		else { System.out.println("Movie title is not displayed"); }
		
		if(driver.findElement(By.className("datebar")).isDisplayed()&&driver.findElement(By.xpath("//div[contains(@class,'date-schedules')]")).isDisplayed()) {
			System.out.println("Movie dates are available");
		}
		else {
			System.out.println("Movie dates are not available");
		}
		
		return new MovieDetailsPage(driver);
	}
	
	public MovieBookingPage selectShowTime() {
		driver.findElement(By.xpath("//div[@class='schedules']/a")).click();
		WebElement okayButton = driver.findElement(By.xpath("//button[text()='Okay']"));
		wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		wait.until(ExpectedConditions.elementToBeClickable(okayButton));
		okayButton.click();
		return new MovieBookingPage(driver);
	}
	
	

}
