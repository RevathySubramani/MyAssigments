package pages.JusTickets;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecific;

public class MovieSearchPage extends ProjectSpecific{

	public MovieSearchPage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public MovieSearchPage enterLocation(String city) {
		driver.findElement(By.className("search")).sendKeys(city);
		return new MovieSearchPage(driver);
	}
	
	public JusTicketsHomePage selectLocation() {
		driver.findElement(By.xpath("//div[@class='state']/div")).click();
		return new JusTicketsHomePage(driver);
	}
}
