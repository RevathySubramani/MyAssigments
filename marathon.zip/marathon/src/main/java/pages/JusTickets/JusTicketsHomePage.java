package pages.JusTickets;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecific;

public class JusTicketsHomePage extends ProjectSpecific{

	public JusTicketsHomePage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public MovieSearchPage clickLocation() {
		driver.findElement(By.xpath("//a[contains(@class,'city-selector')]//span")).click();
		return new MovieSearchPage(driver);
	}
	
	public MovieDetailsPage selectMovie() {
		driver.findElement(By.className("poster")).click();
		return new MovieDetailsPage(driver);
	}
	
}
