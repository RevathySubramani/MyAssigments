package pages.JusTickets;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import base.ProjectSpecific;

public class MovieOrderPage extends ProjectSpecific {

	public MovieOrderPage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public MovieOrderPage reviewBookingDetails() throws InterruptedException {
		Thread.sleep(5000);
		List<WebElement> movieDetails = driver.findElements(By.xpath("//div[@class='value']/span"));
		List<WebElement> seatAndPriceDetails = driver.findElements(By.xpath("//div[@class='box']"));
		if(movieDetails !=null && seatAndPriceDetails !=null) {
			System.out.println("#####Movie Details####");
			for(int i =0; i<movieDetails.size();i++) {
			System.out.println(movieDetails.get(i).getText());
			}
			System.out.println("#####Seat and Price Details####");
			for(int i =0; i<seatAndPriceDetails.size();i++) {
			System.out.println(seatAndPriceDetails.get(i).getText());
			}
		}
		else {
			System.out.println("Values are null");
		}
		 return new MovieOrderPage(driver);
		
	}
	
	public MovieOrderPage choosePayment() {
		driver.findElement(By.xpath("//div[contains(text(),'Credit / Debit')]")).click();
		return new MovieOrderPage(driver);
	}
	
	public MovieOrderPage enterPaymentDetails(String cardNo,String expiryDate,String cvv,String name, String email, String mobile) {
		driver.findElement(By.xpath("//input[@type='tel']")).sendKeys(cardNo);
		driver.findElement(By.xpath("//input[@autocomplete='cc-exp']")).sendKeys(expiryDate);
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys(cvv);
		driver.findElement(By.xpath("//label[text()='Name']/following::input")).sendKeys(name);
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys(email);
		driver.findElement(By.xpath("//div[@class='prefixed-mobile']/input")).sendKeys(mobile);
		return new MovieOrderPage(driver);
		
	}
	
	public MovieOrderPage verifyButtonEnabled() {
		String button = driver.findElement(By.xpath("//span[text()='Enter Valid Card Number']")).getAttribute("class");
		if(button.equalsIgnoreCase("disabled")) {
			System.out.println("Enter valid card number button is greyed out");
		}
		else {
			System.out.println("The button is clickable");
		}

		return new MovieOrderPage(driver);
	}
	
	
}
