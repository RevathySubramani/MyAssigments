package pages.RedHat;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import base.ProjectSpecific;

public class RedHatRegistrationPage extends ProjectSpecific {

	public RedHatRegistrationPage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public RedHatRegistrationPage validatePageTitle() {
		String pageTitle = driver.getTitle();
		Assert.assertEquals(pageTitle,"Register | Red Hat IDP");
		return new RedHatRegistrationPage(driver);
		
	}
	
	public RedHatRegistrationPage isRegisterFormDisplayed() {
		driver.findElement(By.id("kc-register-form")).isDisplayed();
		return new RedHatRegistrationPage(driver);
	}
	
	public RedHatRegistrationPage enterUserDetails(String userID, String password, String confirmPassword, String firstName, String lastName,
			String email, String phone, String job) {
		driver.findElement(By.id("username")).sendKeys(userID);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.id("confirmPassword")).sendKeys(confirmPassword);
		driver.findElement(By.id("firstName")).sendKeys(firstName);
		driver.findElement(By.id("firstName")).sendKeys(lastName);
		driver.findElement(By.id("email")).sendKeys(email);
		driver.findElement(By.id("user.attributes.phoneNumber")).sendKeys(phone);
		driver.findElement(By.id("user.attributes.jobTitle")).sendKeys(job);	
		return new RedHatRegistrationPage(driver);
	}
	
	public RedHatRegistrationPage selectAccountType() {
		driver.findElement(By.xpath("//label[text()='Personal']")).click();
		return new RedHatRegistrationPage(driver);
	}
	
	public RedHatRegistrationPage selectCountry() {
		WebElement country = driver.findElement(By.id("user.attributes.country"));
		Select selectCountry = new Select(country);
		selectCountry.selectByVisibleText("India");
		return new RedHatRegistrationPage(driver);
	}
	public RedHatRegistrationPage enterContactInformation(String address1, String address2, String postalCode, String city) {
		driver.findElement(By.id("user.attributes.addressLine1")).sendKeys(address1);
		driver.findElement(By.id("user.attributes.addressLine2")).sendKeys(address2);
		driver.findElement(By.id("user.attributes.addressPostalCode")).sendKeys(postalCode);
		driver.findElement(By.id("user.attributes.addressCityText")).sendKeys(city);
		return new RedHatRegistrationPage(driver);
	}
	
	public RedHatRegistrationPage selectState() {
		WebElement state = driver.findElement(By.id("user.attributes.addressState"));
		Select selectState = new Select(state);
		selectState.selectByVisibleText("Tamil Nadu");
		return new RedHatRegistrationPage(driver);
	}

}
