package pages.RedHat;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecific;

public class RedHatLoginPage extends ProjectSpecific {
	
	public RedHatLoginPage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public RedHatRegistrationPage clickRegister() {
		driver.findElement(By.xpath("//button[contains(text(), 'Register')]")).click();
		return new RedHatRegistrationPage(driver);
	}

}
